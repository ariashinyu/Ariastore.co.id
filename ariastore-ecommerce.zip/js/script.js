// Mobile Navigation Toggle
document.addEventListener("DOMContentLoaded", () => {
  const hamburger = document.querySelector(".hamburger")
  const nav = document.querySelector(".nav")

  if (hamburger && nav) {
    hamburger.addEventListener("click", () => {
      nav.classList.toggle("active")

      // Animate hamburger
      hamburger.classList.toggle("active")
    })

    // Close mobile menu when clicking on a link
    const navLinks = document.querySelectorAll(".nav a")
    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        nav.classList.remove("active")
        hamburger.classList.remove("active")
      })
    })

    // Close mobile menu when clicking outside
    document.addEventListener("click", (event) => {
      if (!nav.contains(event.target) && !hamburger.contains(event.target)) {
        nav.classList.remove("active")
        hamburger.classList.remove("active")
      }
    })
  }
})

// Smooth Scrolling for Anchor Links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

// Contact Form Handling
const contactForm = document.getElementById("contactForm")
if (contactForm) {
  contactForm.addEventListener("submit", function (e) {
    e.preventDefault()

    // Get form data
    const formData = new FormData(this)
    const name = formData.get("name")
    const email = formData.get("email")
    const message = formData.get("message")

    // Simple validation
    if (!name || !email || !message) {
      alert("Mohon lengkapi semua field!")
      return
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      alert("Format email tidak valid!")
      return
    }

    // Simulate form submission
    alert(`Terima kasih ${name}! Pesan Anda telah dikirim. Kami akan segera menghubungi Anda di ${email}.`)

    // Reset form
    this.reset()
  })
}

// Product Card Hover Effects
document.querySelectorAll(".product-card").forEach((card) => {
  card.addEventListener("mouseenter", function () {
    this.style.transform = "translateY(-10px)"
  })

  card.addEventListener("mouseleave", function () {
    this.style.transform = "translateY(0)"
  })
})

// Buy Button Click Handler
document.querySelectorAll(".btn-primary").forEach((button) => {
  if (button.textContent.includes("Beli")) {
    button.addEventListener("click", (e) => {
      e.preventDefault()
      const productName = document.querySelector("h1")?.textContent || "Produk"
      alert(`Terima kasih! Anda akan diarahkan ke halaman pembayaran untuk ${productName}.`)
    })
  }
})

// Add to Cart Button Handler
document.querySelectorAll(".btn-secondary").forEach((button) => {
  if (button.textContent.includes("Keranjang")) {
    button.addEventListener("click", function (e) {
      e.preventDefault()
      const productName = document.querySelector("h1")?.textContent || "Produk"
      alert(`${productName} telah ditambahkan ke keranjang!`)

      // Change button text temporarily
      const originalText = this.textContent
      this.textContent = "Ditambahkan!"
      this.style.background = "#27ae60"
      this.style.borderColor = "#27ae60"
      this.style.color = "white"

      setTimeout(() => {
        this.textContent = originalText
        this.style.background = "transparent"
        this.style.borderColor = "#3498db"
        this.style.color = "#3498db"
      }, 2000)
    })
  }
})

// Scroll to Top Functionality
window.addEventListener("scroll", () => {
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop

  // Add shadow to header when scrolling
  const header = document.querySelector(".header")
  if (scrollTop > 100) {
    header.style.boxShadow = "0 2px 20px rgba(0,0,0,0.15)"
  } else {
    header.style.boxShadow = "0 2px 10px rgba(0,0,0,0.1)"
  }
})

// Image Loading Error Handler
document.querySelectorAll("img").forEach((img) => {
  img.addEventListener("error", function () {
    this.src = "/placeholder.svg?height=250&width=250&text=Image+Not+Found"
    this.alt = "Image not found"
  })
})

// Form Input Animation
document.querySelectorAll(".form-group input, .form-group textarea").forEach((input) => {
  input.addEventListener("focus", function () {
    this.parentElement.classList.add("focused")
  })

  input.addEventListener("blur", function () {
    if (!this.value) {
      this.parentElement.classList.remove("focused")
    }
  })
})

// Price Formatting
document.querySelectorAll(".price, .price-large").forEach((priceElement) => {
  const price = priceElement.textContent
  // Add thousand separators for better readability
  const formattedPrice = price.replace(/\B(?=(\d{3})+(?!\d))/g, ".")
  priceElement.textContent = formattedPrice
})

// Search Functionality (if needed in future)
function searchProducts(query) {
  const products = document.querySelectorAll(".product-card")
  const searchQuery = query.toLowerCase()

  products.forEach((product) => {
    const productName = product.querySelector("h3").textContent.toLowerCase()
    const productDesc = product.querySelector(".description").textContent.toLowerCase()

    if (productName.includes(searchQuery) || productDesc.includes(searchQuery)) {
      product.style.display = "block"
    } else {
      product.style.display = "none"
    }
  })
}

// Console welcome message
console.log("🛍️ Selamat datang di Ariastore! Website e-commerce sederhana dengan HTML, CSS, dan JavaScript.")
console.log("📱 Website ini responsive dan siap digunakan di desktop maupun mobile.")
